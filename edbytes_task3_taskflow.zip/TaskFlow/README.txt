EdBytes Task FSD-02 — TaskFlow To-do App

Files
- index.html: app source (HTML, CSS, JavaScript in one file)

Implemented
- Adds non-empty task text.
- Displays a Delete button for every task.
- Saves task list to localStorage after adding/deleting.
- Loads saved tasks on page open, so tasks remain after refresh.
- Responsive layout for phone and desktop.

Test note
1. Ordinary test: enter "Finish internship task" and Add task. It appears. Refresh the page; it remains.
2. Boundary/failure test: submit the input empty or with spaces only. The app shows a validation message and does not add a blank task.
3. Delete test: click Delete for one task. It disappears and stays deleted after refresh.

What changed
Connected the form submit handler to validation and task creation, added per-task Delete buttons, and added localStorage save/load with rendering.

What I learned
I learned how JavaScript event listeners respond to form submissions, how arrays keep track of tasks, and how localStorage preserves data in the browser between refreshes.

Note: This project was prepared from the task requirements provided in the prompt. The EdBytes starter ZIP could not be downloaded in this session, so this is a standalone implementation rather than an edit of the supplied skeleton.
